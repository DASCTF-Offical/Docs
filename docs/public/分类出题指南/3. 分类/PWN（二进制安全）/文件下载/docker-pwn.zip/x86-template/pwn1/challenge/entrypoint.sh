#!/bin/sh
./pwn
