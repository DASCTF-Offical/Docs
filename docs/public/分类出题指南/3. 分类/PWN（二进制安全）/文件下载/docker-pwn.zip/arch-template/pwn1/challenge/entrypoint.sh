#!/bin/sh
./qemu-mipsel-static ./mips_pwn
