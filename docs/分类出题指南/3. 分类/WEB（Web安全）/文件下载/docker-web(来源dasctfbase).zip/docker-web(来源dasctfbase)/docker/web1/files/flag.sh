#!/bin/bash

# 1. flag若是文件形式
echo $DASFLAG > /flag

# 2. 也可以直接创建 FLAG 的表，并将值插入进去（ps: 用不到此种情况，把这些注释的内容直接删掉）
# mysql -e "create table flag(flag varchar(256)); insert into flag values('$DASFLAG');" -uroot -proot test

# 3. flag 若是在数据库里的某张表里，譬如 flag 在 secret 表里（ps: 用不到此种情况，把这些注释的内容直接删掉）
# mysql -e "update secret set password='$DASFLAG' where password='DASFLAG'" -uroot -proot test

# 覆盖掉环境变量，防止非预期
export DASFLAG=nonono
DASFLAG=nonono
# 删除自身
rm -f /flag.sh