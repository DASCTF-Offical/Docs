CREATE USER 'test'@'%' IDENTIFIED BY '123456';

CREATE DATABASE test;

use test;

CREATE TABLE users (
  id int(11) primary key auto_increment,
  username varchar(256)
);

INSERT INTO users values (1, 'abc'),(2, 'ccc');


/*
# 对于 flag.sh 里第 3 种情况，若 flag 在 secret 表里
CREATE TABLE secret (
  id int(11),
  username varchar(255),
  password varchar(255)
);
INSERT INTO secret values (1, 'guest', '123456');
INSERT INTO secret values (2, 'flag', 'DASFLAG');
INSERT INTO secret values (3, 'admin', 'admin123');
*/

GRANT ALL ON test.* TO 'test'@'%';
