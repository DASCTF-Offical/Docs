#!/bin/bash
# Add your startup script
if [ ! $DASFLAG ];then
 echo DASCTF{TEST_DASFLAG}|tee /home/ctf/flag
else
 echo $DASFLAG|tee /home/ctf/flag 
fi
chown root:ctf /home/ctf/flag 
chmod 740 /home/ctf/flag

# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;